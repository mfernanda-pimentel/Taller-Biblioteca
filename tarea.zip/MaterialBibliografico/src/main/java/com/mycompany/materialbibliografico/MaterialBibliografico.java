/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.materialbibliografico;

/**
 *
 * @author USUARIO
 */
public abstract class MaterialBibliografico {

    private String titulo;
    private boolean prestado;
    
public MaterialBibliografico(String titulo) {
    this.titulo = titulo;
    this.prestado = false;
}

public String getTitulo() {
    return titulo;
}

public boolean isPrestado() {
    return prestado;
}
public void setPrestado(boolean prestado) {
    this.prestado = prestado;
}
public abstract double calcularMulta(int dias);

public abstract void mostrarInformacion();
}
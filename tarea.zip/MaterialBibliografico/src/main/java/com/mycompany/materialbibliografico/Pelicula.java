/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.materialbibliografico;

/**
 *
 * @author USUARIO
 */
public class Pelicula extends MaterialBibliografico{
    private String director;
    private int duraccion;
    
    public Pelicula(String titulo,String director,int duraccion) {
        super(titulo);
        this.director =  director;
        this.duraccion = duraccion;
    }
   
    
   @Override
   public double calcularMulta(int dias){
       return dias * 10000;
   }
   @Override
   public void mostrarInformacion(){
    System.out.println("Pelicula: " + getTitulo() + 
    "Director: " + director + 
    "Duraccion: " + duraccion + "minutos");
   }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.materialbibliografico;

/**
 *
 * @author USUARIO
 */
public class Libro extends MaterialBibliografico {
    private String autor;
    private int npaginas;
    
    
    public Libro(String titulo, String autor,int npaginas) {
    super(titulo);
    this.autor = autor;
    this.npaginas = npaginas;
}
    @Override
public double calcularMulta(int dias) {
    return dias * 5000;
}
@Override
public void mostrarInformacion() {
    System.out.println("Libro: " + getTitulo() +
    " Autor: " + autor +
    "numero de paginas: " + npaginas);
}
}

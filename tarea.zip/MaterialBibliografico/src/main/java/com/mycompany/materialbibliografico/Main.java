/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.materialbibliografico;

/**
 *
 * @author USUARIO
 */
    import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        ArrayList<MaterialBibliografico> lista = new ArrayList<>();

        lista.add(new Libro("Cien Años de Soledad", "Gabriel Garcia Marquez",200));
        lista.add(new Revista("National Geographic", "Mensual"));
        lista.add(new Pelicula("Titanic", "James Cameron", 195));

        for(MaterialBibliografico m : lista){

            m.mostrarInformacion();

            System.out.println("Multa por 2 dias: $" + m.calcularMulta(2));

            System.out.println("----------------------");

        }

    }

}


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.materialbibliografico;

/**
 *
 * @author USUARIO
 */
public class Revista extends MaterialBibliografico{
    private String periodicidad;
    
    
    
    public Revista(String titulo,String periodicidad){
        super(titulo);
        this.periodicidad = periodicidad;
    }
    
 @Override
public double calcularMulta(int dias) {
    return dias * 3000;
}

@Override
public void mostrarInformacion() {
    System.out.println("Revista: " + getTitulo() + "periodicidad: " + periodicidad);
}
}

